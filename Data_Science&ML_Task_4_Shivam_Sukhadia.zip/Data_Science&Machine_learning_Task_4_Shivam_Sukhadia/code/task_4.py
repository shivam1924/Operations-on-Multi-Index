import pandas as pd
import numpy as np

# Create MultiIndex DataFrame
arrays = [
    ['A', 'A', 'B', 'B', 'C', 'C'],
    ['one', 'two', 'one', 'two', 'one', 'two']
]
index = pd.MultiIndex.from_arrays(arrays, names=('Group', 'Subgroup'))

data = pd.DataFrame({
    'Values': [10, 15, 10, 25, 20, 30],
    'Counts': [5, 10, 5, 10, 10, 15]
}, index=index)

print("Original DataFrame:")
print(data)
print("\nAccess group 'A':")
print(data.loc['A'])
print("\nAccess subgroup 'one' across all groups:")
print(data.xs('one', level='Subgroup'))

print("\nSum values at the 'Group' level:")
print(data.groupby(level='Group').sum())

print("\nMean at the 'Subgroup' level:")
print(data.groupby(level='Subgroup').mean())

print("\nReset MultiIndex:")
print(data.reset_index())

print("\nSet 'Group' as single index:")
print(data.reset_index().set_index('Group'))

print("\nUnstack 'Subgroup' level:")
print(data.unstack(level='Subgroup'))

print("\nStack back:")
print(data.unstack(level='Subgroup').stack())

print("\nAdd a new level:")
data['New Level'] = ['X', 'Y', 'X', 'Y', 'X', 'Y']
data = data.set_index('New Level', append=True)
print(data)

print("\nRemove 'New Level':")
print(data.droplevel('New Level'))

print("\nSort by 'Subgroup':")
print(data.sort_index(level='Subgroup'))

print("\nFilter rows where 'Group' is 'A' or 'B':")
print(data.loc[data.index.get_level_values('Group').isin(['A', 'B'])])

print("\nRename index levels:")
data = data.rename_axis(index={'Group': 'Category', 'Subgroup': 'Type'})
print(data)
